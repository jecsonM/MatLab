x = linspace(-2,2,200);

a=1.6;
b=0.4;
c=2.4;
d=0.3;
y1 = atan(-a+power((x-b),2)).*sin(c+d*power(x,2));
y2= 1.5-0.3.*x-9.86.*power(x,2)-5.58.*power(x,3);

TFMins = islocalmin(y1);
TFMaxs = islocalmax(y1);


plot(x, y1, 'k-', ...
    x(TFMins), y1(TFMins), 'bo', ...
    x(TFMaxs), y1(TFMaxs), 'ro');
title('Уравнение 13');

figure

plot(x,y2, 'k-')


title('полином 13');
xlabel('x');
ylabel('y1');






